/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package waterbill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Calayugan Sur
 */
public class paymentdisplay extends javax.swing.JInternalFrame {
    public static final String DB_URL = "jdbc:mysql://localhost/waterbill";
    public static final String USERNAME = "castilla";
    public static final String PASSWORD = "ning";
    
    DefaultTableModel billmodel, paymentModel; 
     String billcol[] = {"ID","CUSTOMER ID","METER #","BILLING PERIOD","CURRENT READING","TOTAL CONSUMPTION","RATE PER UNIT","DUE DATE","PREVIOUS READING","TOTAL AMOUNT DUE"};
    Object billrow[][];
    
    
    String paymentcol[] = {"ID" , "BILL ID", "PAYMENT DATE" , "PAYABLE", "AMOUNT PAID" ,"CHANGE", "STATUS"};
    Object paymentrow[][];

    /**
     * Creates new form paymentdisplay
     */
    public paymentdisplay() {
        initComponents();
        initialState();
        setPaymentTable();
        setWaterTable();
        change.setEditable(false);
    }
 public void setPaymentTable(){
        paymentModel = new DefaultTableModel(paymentrow, paymentcol);
        paymenttable.setModel(paymentModel);
        
        String sql = "SELECT * FROM payment_info";
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                paymentModel.addRow(new Object[] {rs.getInt("paymentid"), rs.getInt("billid"), rs.getString("paymentdate"),rs.getDouble("payable"),rs.getDouble("amountpaid"),rs.getDouble("change")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }
 public void initialState() {
       // newBtn.setEnabled(true);
        saveBtn.setEnabled(false);
        pid.setEditable(false);
        bd.setEditable(false);
        pad.setEditable(false);
        paid.setEditable(false);   
        amountpayable.setEditable(false);  
        change.setEditable(false);
        updateBtn.setEnabled(false);
     
    }
  public void makeInput() {
        //newBtn.setEnabled(false);
        saveBtn.setEnabled(true);
        pid.setEditable(true);
       bd.setEditable(false);
        pad.setEditable(false);
        paid.setEditable(false);
       amountpayable.setEditable(true);
        change.setEditable(false);
      
    }
  public void setWaterTable() {
        billmodel  = new DefaultTableModel(billrow,billcol);
        billtable.setModel(billmodel);
        
        String sql = "Select * from bill_info";

        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD); 
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);) {
                   
          while(rs.next()) {
                    billmodel.addRow(new Object[]{rs.getInt("billid"), rs.getInt("customerid"),rs.getInt("meterno"), rs.getString("billperiod"), rs.getDouble("currentreading"), rs.getDouble("totalconsumption"), rs.getDouble("rateperunit"), rs.getString("duedate"), rs.getDouble("previousreading"), rs.getDouble("totalamountdue"), rs.getString("ratetype")});
          }

        }catch(SQLException ex) {
              ex.printStackTrace();
        }        
        
    }
   public void getRowNumberWater(){
     int getRowNumber = billtable.getSelectedRow();
    bd.setText(billtable.getValueAt(getRowNumber, 1).toString());
    amountpayable.setText(billtable.getValueAt(getRowNumber, 9).toString());
    pad.setText(billtable.getValueAt(getRowNumber, 6).toString());
    }
   
    public void getBillId(){  
    String sql = "SELECT * FROM bill_info WHERE billid = '"+bd.getText()+"'";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                                ResultSet rs = stmt.executeQuery(sql);){
           
        }catch(SQLException ex){
            ex.printStackTrace();
        }   
    }
     public void addPayment() {
         
         if(Double.parseDouble(amountpayable.getText())>= Double.parseDouble(paid.getText())){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
             Double tchange =   Double.parseDouble(amountpayable.getText()) -Double.parseDouble(paid.getText());
             change.setText(String.valueOf(tchange));
            String sql = "INSERT INTO payment_info VALUES('"+Integer.parseInt(pid.getText())+"','"+Integer.parseInt(bd.getText())+"','"+pad.getText()+"','"+Double.parseDouble(paid.getText())+"','"+Double.parseDouble(amountpayable.getText())+"','"+Double.parseDouble(change.getText())+"','"+"PAID"+"')";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"NEW PAYMENT ADDED!");
             initialState();
            setClear();
            setPaymentTable();
        
        }
         
        
         catch(SQLException ex){
            ex.printStackTrace();
         }
        
    }
          else{
         JOptionPane.showMessageDialog(null,"Insufficient Payment!","",JOptionPane.ERROR_MESSAGE);
         }
     }
     
        public void setClear() {
        pid.setText("");
        bd.setText("");
        pad.setText("");
        amountpayable.setText("");
        paid.setText("");
        change.setText("");
          }
         
         public void makeEdit() {
        pid.setEditable(true);
        bd.setEditable(true);
        pad.setEditable(true);
        paid.setEditable(true);
        amountpayable.setEditable(true);
        change.setEditable(true);
        
    }
         
         public void updateData() {
        Double change = Double.parseDouble(amountpayable.getText()) - Double.parseDouble(paid.getText());
       try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement stmt = conn.createStatement();){
               String sql = "UPDATE payment_info SET billid='"+Integer.parseInt(bd.getText())+"',paymentdate='"+pad.getText()+"',amountpaid='"+Double.parseDouble(amountpayable.getText())+"',change = '"+change+"' WHERE paymentid='"+Integer.parseInt(pid.getText())+"'";
                stmt.executeUpdate(sql);
               JOptionPane.showMessageDialog(null, "UPDATE SUCCESSFULLY");
               setPaymentTable();

          setClear();
        initialState(); 
        paymenttable.clearSelection();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
    }
         public void getRowNumberPayment(){
       int getRowNumber = paymenttable.getSelectedRow();
      pid.setText(paymenttable.getValueAt(getRowNumber, 0).toString());
      bd.setText(paymenttable.getValueAt(getRowNumber, 1).toString());
      pad.setText(paymenttable.getValueAt(getRowNumber, 2).toString());
    paid.setText(paymenttable.getValueAt(getRowNumber, 3).toString());
    amountpayable.setText(paymenttable.getValueAt(getRowNumber, 4).toString());
       change.setText(paymenttable.getValueAt(getRowNumber, 5).toString()); 
      
    }
      public void deleteData(){
       try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
           String sql = "DELETE from payment_info WHERE paymentid='"+Integer.valueOf(pid.getText())+"'";
          stmt.executeUpdate(sql);
          JOptionPane.showMessageDialog(null, "DELETE SUCCESSFULLY");
          setClear();
        initialState();
        setPaymentTable();
     }catch(SQLException ex){
         ex.printStackTrace();
     }
  }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        paymenttable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pid = new javax.swing.JTextField();
        bd = new javax.swing.JTextField();
        pad = new javax.swing.JTextField();
        amountpayable = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        billtable = new javax.swing.JTable();
        newBtn = new javax.swing.JButton();
        saveBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        paid = new javax.swing.JTextField();
        change = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("ADD PAYMENT");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 0, -1, -1));

        paymenttable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        paymenttable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymenttableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(paymenttable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 35, 770, 120));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("PAYMENT ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 38, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("BILL ID:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 93, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 255));
        jLabel4.setText("PAYMENT DATE:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 158, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setText(" AMOUNT PAYABLE:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 218, -1, -1));

        pid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pidKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pidKeyTyped(evt);
            }
        });
        getContentPane().add(pid, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 65, 147, -1));
        getContentPane().add(bd, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 121, 147, -1));
        getContentPane().add(pad, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 184, 147, -1));

        amountpayable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                amountpayableKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                amountpayableKeyTyped(evt);
            }
        });
        getContentPane().add(amountpayable, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 252, 144, -1));

        billtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        billtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                billtableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(billtable);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 167, 770, 110));

        newBtn.setBackground(new java.awt.Color(0, 0, 0));
        newBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newBtn.setForeground(new java.awt.Color(0, 255, 255));
        newBtn.setText("NEW");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });
        getContentPane().add(newBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 320, -1, -1));

        saveBtn.setBackground(new java.awt.Color(0, 0, 0));
        saveBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        saveBtn.setForeground(new java.awt.Color(0, 255, 255));
        saveBtn.setText("SAVE");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(saveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 320, -1, -1));

        updateBtn.setBackground(new java.awt.Color(0, 0, 0));
        updateBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(0, 255, 255));
        updateBtn.setText("UPDATE");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        getContentPane().add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 320, -1, -1));

        deleteBtn.setBackground(new java.awt.Color(0, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(0, 255, 255));
        deleteBtn.setText("DELETE");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        getContentPane().add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 320, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 255, 255));
        jLabel8.setText("CHANGE:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));
        getContentPane().add(paid, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 150, -1));
        getContentPane().add(change, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 380, 150, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 255, 255));
        jLabel7.setText("PAID:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/waterbill/wateraesthetic.jpg"))); // NOI18N
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, -20, 980, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void billtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_billtableMouseClicked
        // TODO add your handling code here:
         getRowNumberWater();
        getBillId();
                  
    }//GEN-LAST:event_billtableMouseClicked

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
        // TODO add your handling code here:
          setClear();
       billtable.clearSelection();
       paymenttable.clearSelection();
       
                    
    }//GEN-LAST:event_newBtnActionPerformed

    private void paymenttableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymenttableMouseClicked
        // TODO add your handling code here:
         makeEdit();
   getRowNumberPayment();  
        int selectedrow = paymenttable.getSelectedRowCount();
        if(selectedrow>0){
            updateBtn.setEnabled(true);
        }
    }//GEN-LAST:event_paymenttableMouseClicked

    private void pidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pidKeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(Character.isDigit(c)){
                if(pid.getText().length()==12){
                       evt.consume();
                }
        }else{
            evt.consume();
        
    }                
    }//GEN-LAST:event_pidKeyTyped

    private void pidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pidKeyReleased
        // TODO add your handling code here:
  if(amountpayable.getText().length()>0 && pid.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        }
    }//GEN-LAST:event_pidKeyReleased

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
              updateData();
           
              
    }//GEN-LAST:event_updateBtnActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // TODO add your handling code here:
         
        addPayment();
    }//GEN-LAST:event_saveBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
          deleteData();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void amountpayableKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountpayableKeyTyped
 char c = evt.getKeyChar();
        if(!Character.isDigit(c)){   
                       evt.consume(); 
        
    }                               
    }//GEN-LAST:event_amountpayableKeyTyped

    private void amountpayableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountpayableKeyReleased
        // TODO add your handling code here:
        if(amountpayable.getText().length()>0 && pid.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
    }                   
    }//GEN-LAST:event_amountpayableKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amountpayable;
    private javax.swing.JTextField bd;
    private javax.swing.JTable billtable;
    private javax.swing.JTextField change;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton newBtn;
    private javax.swing.JTextField pad;
    private javax.swing.JTextField paid;
    private javax.swing.JTable paymenttable;
    private javax.swing.JTextField pid;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
