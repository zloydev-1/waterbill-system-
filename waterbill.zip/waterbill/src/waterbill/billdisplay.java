/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package waterbill;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Calayugan Sur
 */
public class billdisplay extends javax.swing.JInternalFrame {
 public static final String DB_URL = "jdbc:mysql://localhost/waterbill";
    public static final String USERNAME = "castilla";
    public static final String PASSWORD = "ning";
         DefaultTableModel customermodel, billmodel;
    String customercol[] = {"ID","NAME","ADDRESS","METER #","CONTACT #"};
    Object customerrow[][];

    String billcol[] = {"ID","CUSTOMER ID","METER NUMBER","BILLING PERIOD","CURRENT READING","TOTAL CONSUMPTION","RATE PER UNIT","DUE DATE","PREVIOUS READING","TOTAL AMOUNT DUE"};
    Object billrow[][];
    
    
    
    public billdisplay() {
        initComponents();
        initialState();
        setBillTable();
        setCustomerTable();
  
    }
      public void setBillTable() {
        billmodel  = new DefaultTableModel(billrow,billcol);
        billtable.setModel(billmodel);
        
        String sql = "Select * from bill_info";

        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD); 
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);) {
                   
          while(rs.next()) {
                    billmodel.addRow(new Object[]{rs.getInt("billid"), rs.getInt("customerid"),rs.getInt("meterno"),rs.getString("billperiod"), rs.getDouble("currentreading"), rs.getDouble("totalconsumption"), rs.getDouble("rateperunit"), rs.getString("duedate"), rs.getDouble("previousreading"), rs.getDouble("totalamountdue")});
          }

        }catch(SQLException ex) {
              ex.printStackTrace();
        }   
      }
         public void initialState() {

      //  newBtn.setEnabled(true);
        saveBtn.setEnabled(false);
        newBtn.setEnabled(true);
        bd.setEditable(false);
        cusid.setEditable(false);
        mn.setEditable(false);
        bp.setEditable(false);
       cr.setEditable(false);
        tc.setEditable(false);
        rt.setEditable(false);
        dd.setEditable(false);
        pr.setEditable(false);
        tmd.setEditable(false);
        updateBtn.setEnabled(false);
        rpu.setEditable(false);
    }
 public void makeInput() {
       
         newBtn.setEnabled(false);
        saveBtn.setEnabled(true);
        bd.setEditable(true);
        cusid.setEditable(true);
        mn.setEditable(true);
        bp.setEditable(true);
       cr.setEditable(true);
        tc.setEditable(false);
        rt.setEditable(true);
        dd.setEditable(true);
        pr.setEditable(true);
        tmd.setEditable(false);
        updateBtn.setEnabled(true);
        rpu.setEditable(false);
        
    }
    public void setCustomerTable() {
        customermodel  = new DefaultTableModel(customerrow,customercol);
        customerTable.setModel(customermodel);
        
        String sql = "SELECT * FROM cust_info";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                customermodel.addRow(new Object []{rs.getInt("cust_id"), rs.getString("fname"), rs.getString("address"), rs.getString("contact_num"),rs.getInt("meternum")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }  
    }
     public void getRowNumberCustomer(){
        int getRowBookId = customerTable.getSelectedRow();
        cusid.setText(customerTable.getValueAt(getRowBookId,0).toString());
         mn.setText(customerTable.getValueAt(getRowBookId,4).toString());
    }
public void addBill() {
      
           try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD); 
         Statement stmt = conn.createStatement();) {
             
        String ratetype =rt.getSelectedItem().toString();
             
        if(ratetype.equals("Residential")) {
            rpu.setText("10.00");
        } else if (ratetype.equals("Commercial")) {
         rpu.setText("12.00");
        } else if (ratetype.equals("Industrial")) {
            rpu.setText("15.00");
        } else {
             rpu.setText("10.00"); // Default rate per unit if rate type is not recognized
        }
        
        double rate = Double.parseDouble(rpu.getText());     
        double totalconsumption = Double.parseDouble(cr.getText()) - Double.parseDouble(pr.getText());
        double totalamountdue = totalconsumption * rate;
       
        // Set the computed ratekwh value to the ratekwhTF field
       tc.setText(""+totalconsumption);
        tmd.setText(""+totalamountdue);
        int Id = Integer.parseInt(bd.getText());
        int cid = Integer.parseInt(cusid.getText());
        int m = Integer.parseInt (mn.getText());
        double r = Double.parseDouble(cr.getText());
        double ppr = Double.parseDouble(pr.getText());
        
        
        String sql = String.format("INSERT INTO bill_info VALUES (%d,%d,%d,'%s',%.2f,%.2f,%.2f,'%s',%.2f,%.2f,'%s')",Id,cid,m,bp.getText(),r,totalconsumption,rate,dd.getText(),ppr,totalamountdue,ratetype);
        stmt.executeUpdate(sql);
        JOptionPane.showMessageDialog(null, "NEW WATER BILLS ADDED!");
         
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
            public void setClear(){
        bd.setText("");
        cusid.setText("");
        mn.setText("");
       bp.setText("");
       cr.setText("");
        tc.setText("");
        dd.setText("");
        pr.setText("");
        tmd.setText("");
        rpu.setText("");
    }
 public void makeEdit() {
         bd.setEditable(true);
        cusid.setEditable(true);
        mn.setEditable(true);
        bp.setEditable(true);
       cr.setEditable(true);
        tc.setEditable(true);
        rt.setEditable(true);
        dd.setEditable(true);
        pr.setEditable(true);
        tmd.setEditable(true);
        updateBtn.setEnabled(true);
        rpu.setEditable(true);
     
    }
public void updateData() {
        String ratetype = rt.getSelectedItem().toString();
        double rateperunit;
             
        if (ratetype.equals("Residential")) {
            rateperunit = 10.00;
        } else if (ratetype.equals("Commercial")) {
            rateperunit = 12.00;
        } else if (ratetype.equals("Industrial")) {
            rateperunit = 15.00;
        } else {
            rateperunit = 10.00; // Default rate per kilowatt-hour if rate type is not recognized
        }
     double totalconsumption = Double.parseDouble(cr.getText()) - Double.parseDouble(pr.getText());
        double totalamountdue = totalconsumption * rateperunit; // Computation of total cost amount
        // Set the computed ratekwh value to the ratekwhTF field
        tc.setText(""+totalconsumption);
        tmd.setText(""+totalamountdue);
        rpu.setText(Double.toString(rateperunit));
String sql = Integer.parseInt(bd.getText()) + "UPDATE bill_info SET customerid='" + Integer.parseInt(cusid.getText()) + "',meterno='" + Integer.parseInt(mn.getText()) + "',billperiod='" + bp.getText() + "',currentreading='" + Double.parseDouble(cr.getText()) + "', totalconsumption='"+Double.parseDouble(tc.getText())+"',rateperunit='" + Double.parseDouble(rpu.getText()) + "', duedate='" + dd.getText() + "',previousreading='" + Double.parseDouble(pr.getText()) + "',totalamountdue='" + Double.parseDouble(tmd.getText()) + "',ratetype='" + rt.getSelectedItem().toString()  + "' WHERE billid='" + "'";
    try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
         Statement stmt = conn.createStatement();) {
        stmt.executeUpdate(sql);
        JOptionPane.showMessageDialog(null, "UPDATE SUCCESSFULLY");
        billtable.clearSelection();
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}
public void getRowNumberWater(){
        int getRowNumber = billtable.getSelectedRow();
        bd.setText(billmodel.getValueAt(getRowNumber, 0).toString());
        cusid.setText(billmodel.getValueAt(getRowNumber, 1).toString());
        mn.setText(billmodel.getValueAt(getRowNumber, 2).toString());
        bp.setText(billmodel.getValueAt(getRowNumber, 3).toString());
        cr.setText(billmodel.getValueAt(getRowNumber, 4).toString());
       tc.setText(billmodel.getValueAt(getRowNumber, 5).toString());
       rt.setSelectedItem(billmodel.getValueAt(getRowNumber, 6).toString());
        dd.setText(billmodel.getValueAt(getRowNumber, 7).toString());
        pr.setText(billmodel.getValueAt(getRowNumber, 8).toString());
       tmd.setText(billmodel.getValueAt(getRowNumber, 9).toString());
       rpu.setText(billmodel.getValueAt(getRowNumber, 10).toString());
}
     public void deleteData(){
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql;
            sql = "DELETE from bill_info WHERE billid='"+Integer.parseInt(bd.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "DELETE SUCCESSFULLY");
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }
        
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        billtable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        rt = new javax.swing.JComboBox<>();
        bd = new javax.swing.JTextField();
        cusid = new javax.swing.JTextField();
        mn = new javax.swing.JTextField();
        bp = new javax.swing.JTextField();
        pr = new javax.swing.JTextField();
        cr = new javax.swing.JTextField();
        tc = new javax.swing.JTextField();
        tmd = new javax.swing.JTextField();
        dd = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        customerTable = new javax.swing.JTable();
        newBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        rpu = new javax.swing.JTextField();
        saveBtn = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();

        jLabel12.setText("jLabel12");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        billtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        billtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                billtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(billtable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(381, 51, 600, 108));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("ADD BILL");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 0, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("BILL ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 29, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("CUSTOMER ID:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 79, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 255));
        jLabel4.setText("METER NUMBER:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 129, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setText("BILLING PERIOD:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 179, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 255, 255));
        jLabel6.setText("PREVIOUS READING:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 79, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 255, 255));
        jLabel7.setText("CURRENT READING:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 229, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 255, 255));
        jLabel8.setText("TOTAL CONSUMPTION:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 279, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 255));
        jLabel9.setText("RATE PER UNIT:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 255, 255));
        jLabel10.setText("TOTAL AMOUNT DUE:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 129, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("DUE DATE:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 29, -1, -1));

        rt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT", "Residential", "Industrial", "Commercial" }));
        rt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rtActionPerformed(evt);
            }
        });
        getContentPane().add(rt, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, -1, -1));

        bd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bdActionPerformed(evt);
            }
        });
        bd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bdKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bdKeyTyped(evt);
            }
        });
        getContentPane().add(bd, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 51, 148, -1));

        cusid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cusidKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cusidKeyTyped(evt);
            }
        });
        getContentPane().add(cusid, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 101, 151, -1));
        getContentPane().add(mn, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 151, 151, -1));

        bp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bpKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bpKeyTyped(evt);
            }
        });
        getContentPane().add(bp, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 201, 151, -1));

        pr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                prKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                prKeyTyped(evt);
            }
        });
        getContentPane().add(pr, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 101, 128, -1));

        cr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                crKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                crKeyTyped(evt);
            }
        });
        getContentPane().add(cr, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 251, 152, -1));
        getContentPane().add(tc, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 304, 153, -1));
        getContentPane().add(tmd, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 151, 128, -1));

        dd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ddKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ddKeyTyped(evt);
            }
        });
        getContentPane().add(dd, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 51, 128, -1));

        customerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        customerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customerTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(customerTable);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 190, 600, 110));

        newBtn.setBackground(new java.awt.Color(0, 0, 0));
        newBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newBtn.setForeground(new java.awt.Color(0, 255, 255));
        newBtn.setText("NEW");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });
        getContentPane().add(newBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 330, -1, -1));

        updateBtn.setBackground(new java.awt.Color(0, 0, 0));
        updateBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(0, 255, 255));
        updateBtn.setText("UPDATE");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        getContentPane().add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, -1, -1));

        deleteBtn.setBackground(new java.awt.Color(0, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(0, 255, 255));
        deleteBtn.setText("DELETE");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        getContentPane().add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 255, 255));
        jLabel14.setText("RATE TYPE:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, -1));
        getContentPane().add(rpu, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, 130, -1));

        saveBtn.setText("SAVE");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(saveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 330, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/waterbill/wateraesthetic.jpg"))); // NOI18N
        jLabel13.setText("jLabel13");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 990, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bdActionPerformed

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
 setClear();
        billtable.clearSelection();
        makeInput();
                                          
       
    }//GEN-LAST:event_newBtnActionPerformed

    private void rtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rtActionPerformed

    private void customerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customerTableMouseClicked
        // TODO add your handling code here:
           getRowNumberCustomer();
    }//GEN-LAST:event_customerTableMouseClicked

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // TODO add your handling code here:
        initialState();
        addBill();
        setClear();
        setBillTable();
                         
    }//GEN-LAST:event_saveBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
         deleteData();
        setClear();
        initialState();
        setBillTable();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        updateData();
        setBillTable();
        setClear();
        initialState();
                        
    }//GEN-LAST:event_updateBtnActionPerformed

    private void billtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_billtableMouseClicked
        // TODO add your handling code here:
        int selrow = billtable.getSelectedRowCount();
       if(selrow >0){
       updateBtn.setEnabled(true);
       }
        makeEdit();
        getRowNumberWater();
        
    }//GEN-LAST:event_billtableMouseClicked

    private void bdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bdKeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(Character.isDigit(c)){
           
                if(bd.getText().length()==12){
                       evt.consume();
                }
        }else{
            evt.consume();
        
    }                     
    }//GEN-LAST:event_bdKeyTyped

    private void bdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bdKeyReleased
        // TODO add your handling code here:
         if(pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 &&bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
    }                                
    }//GEN-LAST:event_bdKeyReleased

    private void cusidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cusidKeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(Character.isDigit(c)){
                if(cusid.getText().length()==12){
                       evt.consume();
                }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_cusidKeyTyped

    private void bpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bpKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(Character.isLetter(c) || c =='-' || c=='ñ' || c=='.'|| c==',' || Character.isDigit(c) || Character.isWhitespace(c)  ) {
            if(bp.getText().length()==50){
                evt.consume();
            }

        }else{
            evt.consume();

        }       
    }//GEN-LAST:event_bpKeyTyped

    private void bpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bpKeyReleased
        // TODO add your handling code here:
        if(pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 && bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
                                             
        }
    }//GEN-LAST:event_bpKeyReleased

    private void cusidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cusidKeyReleased
        if(pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 && bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
                
        }

    }//GEN-LAST:event_cusidKeyReleased

    private void ddKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ddKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(Character.isLetter(c) || c =='-' || c=='ñ' || c=='.' || c==',' || Character.isWhitespace(c) || Character.isDigit(c) ) {
            dd.setBackground(Color.pink);
            if(dd.getText().length()==50){
                evt.consume();
            }

        }else{
            evt.consume();

        }       
    }//GEN-LAST:event_ddKeyTyped

    private void ddKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ddKeyReleased
        // TODO add your handling code here:
        if(pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 && bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
        }                        
    }//GEN-LAST:event_ddKeyReleased

    private void crKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_crKeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c)){   
                       evt.consume(); 
        
    }                               
    }//GEN-LAST:event_crKeyTyped

    private void crKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_crKeyReleased
        // TODO add your handling code here:'
if(pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 && bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
    }                           
    }//GEN-LAST:event_crKeyReleased

    private void prKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_prKeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c)){   
                       evt.consume(); 
        
    }                         
    }//GEN-LAST:event_prKeyTyped

    private void prKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_prKeyReleased
        // TODO add your handling code here:
        if( pr.getText().length()>0 && cr.getText().length()>0 && dd.getText().length()>0 && bd.getText().length()>0 && mn.getText().length()>0 && bp.getText().length()>0 && cusid.getText().length()>0 && bd.getText().length()>0 ){
            saveBtn.setEnabled(true);
        }else{
            saveBtn.setEnabled(false);
        
        }                              
    }//GEN-LAST:event_prKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bd;
    private javax.swing.JTable billtable;
    private javax.swing.JTextField bp;
    private javax.swing.JTextField cr;
    private javax.swing.JTextField cusid;
    private javax.swing.JTable customerTable;
    private javax.swing.JTextField dd;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField mn;
    private javax.swing.JButton newBtn;
    private javax.swing.JTextField pr;
    private javax.swing.JTextField rpu;
    private javax.swing.JComboBox<String> rt;
    private javax.swing.JButton saveBtn;
    private javax.swing.JTextField tc;
    private javax.swing.JTextField tmd;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
