/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package waterbill;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author Calayugan Sur
 */
public class cashierdisplay extends javax.swing.JInternalFrame {
   public static final String DB_URL = "jdbc:mysql://localhost/waterbill";
    public static final String USERNAME = "castilla";
    public static final String PASSWORD = "ning";

    
    DefaultTableModel model;
    String col[]={"ID" ,"NAME","CONTACT NUMBER","EMAIL","PASSWORD"};
    Object row[][];
    /**
     *
     */
    public cashierdisplay() {
        initComponents();
        initialState();
        setCashierTable();
    }
    public void setCashierTable(){
        model = new DefaultTableModel (row,col);
        ctable.setModel(model);
        
        String sql = "SELECT * FROM cash_info";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
               Statement stmt= conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
           while(rs.next()){
               model.addRow(new Object []{rs.getInt("cashierid"), rs.getString("cash_name"), rs.getString("contact_number"), rs.getString("email"), rs.getString("password")});
               
           }
         }catch(SQLException ex){
              ex.printStackTrace();
        }
    }
    
    public void initialState(){
        newBtn.setEnabled(true);
        saveBtn.setEnabled(false);
        cId.setEditable(false);
        cname.setEditable(false);
        cont.setEditable(false);
        mail.setEditable(false);
        pass.setEditable(false);
    }
    public void makeInput(){
        newBtn.setEnabled(false);
        saveBtn.setEnabled(true);
        cId.setEditable(true);
        cname.setEditable(true);
        cont.setEditable(true);
        mail.setEditable(true);
        pass.setEditable(true);
    }
    
    public void addCashier(){
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
               Statement stmt= conn.createStatement();){
            int ID = Integer.parseInt(cId.getText());
            int con = Integer.parseInt(cont.getText());
           String sql = String.format("INSERT INTO cash_info VALUES (%d,'%s',%d,'%s','%s')",ID,cname.getText(),con,mail.getText(),pass.getText());
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "NEW CASHIER ADDED!");
}catch(SQLException ex){
    ex.printStackTrace();
        }
        
    }
    public void setClear(){
        cId.setEditable(true);
        cname.setEditable(true);
        cont.setEditable(true);
        mail.setEditable(true);
        pass.setEditable(true);
        
    }
    public void makeEdit(){
        cId.setEditable(true);
        cname.setEditable(true);
        cont.setEditable(true);
        mail.setEditable(true);
        pass.setEditable(true);
    }
   
    public void updateData(){
         try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
               Statement stmt= conn.createStatement()){
             
             int ID = Integer.parseInt(cId.getText());
             String con =(cname.getText());
             int met = Integer.parseInt(cont.getText());
            String mil = (mail.getText());
             String lpassw =(pass.getText());
            String sql = String.format("UPDATE cash_info SET cash_name = '%s',contact_number = %d, email = '%s' ,password= '%s' WHERE cashierid = %d ",con,met,mil,lpassw,ID);
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "UPDATE SUCCESSFULLY");
}catch(SQLException ex){
    ex.printStackTrace();
        
    }
}
     public void displayDataToTextField(){
         int getRowNumber = ctable.getSelectedRow();
         cId.setText(model.getValueAt(getRowNumber,0).toString());
         cname.setText(model.getValueAt(getRowNumber,1).toString());
         cont.setText(model.getValueAt(getRowNumber,2).toString());
         mail.setText(model.getValueAt(getRowNumber,3).toString());
         pass.setText(model.getValueAt(getRowNumber,4).toString());
         
     }
     public void deleteData(){
         try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
               Statement stmt= conn.createStatement();){
             int id = Integer.parseInt(cId.getText());
             String sql= String.format("DELETE from cash_info WHERE cashierid = %d",id);
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "DELETE SUCCESSFULLY");
}catch(SQLException ex){
    ex.printStackTrace();
         }
         
     }
     

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        saveBtn = new javax.swing.JButton();
        newBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cId = new javax.swing.JTextField();
        cname = new javax.swing.JTextField();
        cont = new javax.swing.JTextField();
        mail = new javax.swing.JTextField();
        pass = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ctable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(809, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("ADD CASHIER");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 0, -1, -1));

        saveBtn.setBackground(new java.awt.Color(0, 0, 0));
        saveBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        saveBtn.setForeground(new java.awt.Color(0, 255, 255));
        saveBtn.setText("SAVE");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(saveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(159, 25, -1, -1));

        newBtn.setBackground(new java.awt.Color(0, 0, 0));
        newBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newBtn.setForeground(new java.awt.Color(0, 255, 255));
        newBtn.setText("NEW");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });
        getContentPane().add(newBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(293, 25, -1, -1));

        updateBtn.setBackground(new java.awt.Color(0, 0, 0));
        updateBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(0, 255, 255));
        updateBtn.setText("UPDATE");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        getContentPane().add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 25, -1, -1));

        deleteBtn.setBackground(new java.awt.Color(0, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(0, 255, 255));
        deleteBtn.setText("DELETE");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        getContentPane().add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(556, 25, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("CASHIER ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 234, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("CASHIER NAME:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 284, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 255));
        jLabel4.setText("CONTACT NUMBER:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 336, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setText("EMAIL:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 255, 255));
        jLabel6.setText("PASSWORD:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 280, -1, -1));
        getContentPane().add(cId, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 130, -1));
        getContentPane().add(cname, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 130, -1));
        getContentPane().add(cont, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, 130, -1));
        getContentPane().add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 240, 150, -1));
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 150, -1));

        ctable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ctable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ctableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(ctable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 850, 150));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/waterbill/wateraesthetic.jpg"))); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -24, 1010, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
                makeInput();        
    }//GEN-LAST:event_newBtnActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        initialState();
        addCashier();
        setClear();
        setCashierTable();
    }//GEN-LAST:event_saveBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        updateData();
        setCashierTable();
        setClear();
        initialState();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        deleteData();
        setClear();
        initialState();
        setCashierTable();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void ctableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ctableMouseClicked
        // TODO add your handling code here:
         int getRowNumber = ctable.getSelectedRow();
         cId.setText(ctable.getValueAt(getRowNumber,0).toString());
         cname.setText(ctable.getValueAt(getRowNumber,1).toString());
         cont.setText(ctable.getValueAt(getRowNumber,2).toString());
         mail.setText(ctable.getValueAt(getRowNumber,3).toString());
         pass.setText(ctable.getValueAt(getRowNumber,4).toString());
    }//GEN-LAST:event_ctableMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cId;
    private javax.swing.JTextField cname;
    private javax.swing.JTextField cont;
    private javax.swing.JTable ctable;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mail;
    private javax.swing.JButton newBtn;
    private javax.swing.JTextField pass;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
