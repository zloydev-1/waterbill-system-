-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 09:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waterbill`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_info`
--

CREATE TABLE `bill_info` (
  `billid` int(10) NOT NULL,
  `customerid` int(10) NOT NULL,
  `meterno` int(10) NOT NULL,
  `billperiod` varchar(50) NOT NULL,
  `currentreading` double(100,2) NOT NULL,
  `totalconsumption` double(100,2) NOT NULL,
  `rateperunit` double(100,2) NOT NULL,
  `duedate` varchar(50) NOT NULL,
  `previousreading` double(100,2) NOT NULL,
  `totalamountdue` double(100,2) NOT NULL,
  `ratetype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill_info`
--

INSERT INTO `bill_info` (`billid`, `customerid`, `meterno`, `billperiod`, `currentreading`, `totalconsumption`, `rateperunit`, `duedate`, `previousreading`, `totalamountdue`, `ratetype`) VALUES
(3, 3, 134, ' march', 100.00, 50.00, 10.00, 'may', 50.00, 500.00, 'Residential'),
(6, 1, 34, '9', 9.00, 6.00, 15.00, '33', 3.00, 90.00, 'Industrial');

-- --------------------------------------------------------

--
-- Table structure for table `cahser`
--

CREATE TABLE `cahser` (
  `cashierid` int(1) NOT NULL,
  `cashier_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cahser`
--

INSERT INTO `cahser` (`cashierid`, `cashier_name`, `email`, `password`) VALUES
(1, 'hh', 'gg', 'gg'),
(2, 'angelo', 'a', 'a'),
(3, 'gelo almerol', 'a', 'a'),
(4, '', '', ''),
(5, 'niningbuang', 'a', 'a'),
(6, 'nining buang', 'a', 'a'),
(7, 'buang ka', 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `cash_info`
--

CREATE TABLE `cash_info` (
  `cashierid` int(1) NOT NULL,
  `cash_name` varchar(100) NOT NULL,
  `contact_number` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cash_info`
--

INSERT INTO `cash_info` (`cashierid`, `cash_name`, `contact_number`, `email`, `password`) VALUES
(1, 'ning', 9090, 'admin', 'admin'),
(5, 'regine ilka', 983, 'gagaxzczcczczc', 'abcd'),
(8, 'MIKA', 9090, 'aaa', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `cust_info`
--

CREATE TABLE `cust_info` (
  `cust_id` int(1) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_num` int(11) NOT NULL,
  `meternum` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cust_info`
--

INSERT INTO `cust_info` (`cust_id`, `fname`, `address`, `contact_num`, `meternum`) VALUES
(2, 'Ning', 'Bohol', 213, 12),
(3, 'alona', 'bohol', 312, 134),
(5, 'MIKA', 'CALAYUGAN', 990, 543);

-- --------------------------------------------------------

--
-- Table structure for table `payment_info`
--

CREATE TABLE `payment_info` (
  `paymentid` int(1) NOT NULL,
  `billid` int(1) NOT NULL,
  `paymentdate` varchar(100) NOT NULL,
  `payable` double(100,2) NOT NULL,
  `amountpaid` double(100,2) NOT NULL,
  `change` double(100,2) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill_info`
--
ALTER TABLE `bill_info`
  ADD PRIMARY KEY (`billid`);

--
-- Indexes for table `cahser`
--
ALTER TABLE `cahser`
  ADD PRIMARY KEY (`cashierid`);

--
-- Indexes for table `cash_info`
--
ALTER TABLE `cash_info`
  ADD PRIMARY KEY (`cashierid`);

--
-- Indexes for table `cust_info`
--
ALTER TABLE `cust_info`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `payment_info`
--
ALTER TABLE `payment_info`
  ADD PRIMARY KEY (`paymentid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cahser`
--
ALTER TABLE `cahser`
  MODIFY `cashierid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cash_info`
--
ALTER TABLE `cash_info`
  MODIFY `cashierid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
